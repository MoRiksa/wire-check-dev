import RPi.GPIO as GPIO
import time

# GPIO pin assignments
RED_LED = 2
YELLOW_LED = 3
GREEN_LED = 4

# Wire pairs (output, input)
WIRE_PAIRS = [
    (17, 27),  # Pair 1
    (22, 10),  # Pair 2
    (9, 11),    # Pair 3
    (5, 6)     # Pair 4
]

# Setup
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(RED_LED, GPIO.OUT)
GPIO.setup(GREEN_LED, GPIO.OUT)
GPIO.setup(YELLOW_LED, GPIO.OUT)

# Setup all output pins
for output_pin, input_pin in WIRE_PAIRS:
    GPIO.setup(output_pin, GPIO.OUT)
    GPIO.setup(input_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

def test_wire_pair(output_pin, input_pin):
    """Test if a wire pair is properly connected"""
    # Send HIGH signal
    GPIO.output(output_pin, GPIO.HIGH)
    time.sleep(0.01)
    high_received = GPIO.input(input_pin)
    
    # Send LOW signal
    GPIO.output(output_pin, GPIO.LOW)
    time.sleep(0.01)
    low_received = GPIO.input(input_pin)
    
    # Return True if properly connected (HIGH when output is HIGH, LOW when output is LOW)
    return high_received and not low_received

def test_cross_connections():
    """Test for cross connections between different pairs"""
    cross_connections = []
    
    # Test if output from one pair affects input of another pair
    for i, (out1, in1) in enumerate(WIRE_PAIRS):
        for j, (out2, in2) in enumerate(WIRE_PAIRS):
            if i != j:  # Don't test same pair
                # Test if output from pair i affects input of pair j
                GPIO.output(out1, GPIO.HIGH)
                time.sleep(0.01)
                if GPIO.input(in2):  # Cross connection detected
                    cross_connections.append((i, j))
                GPIO.output(out1, GPIO.LOW)
                time.sleep(0.01)
    
    return cross_connections

def test_in_to_in_connections():
    """Test if any input pins are connected to each other"""
    input_pins = [in_pin for _, in_pin in WIRE_PAIRS]
    in_to_in_connections = []
    
    for i, in1 in enumerate(input_pins):
        for j, in2 in enumerate(input_pins):
            if i != j:
                # Set one input as output temporarily to test connection
                GPIO.setup(in1, GPIO.OUT)
                GPIO.output(in1, GPIO.HIGH)
                time.sleep(0.01)
                if GPIO.input(in2):  # IN-to-IN connection detected
                    in_to_in_connections.append((i, j))
                GPIO.output(in1, GPIO.LOW)
                GPIO.setup(in1, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Restore as input
    
    return in_to_in_connections

def test_out_to_out_connections():
    """Test if any output pins are connected to each other"""
    output_pins = [out_pin for out_pin, _ in WIRE_PAIRS]
    out_to_out_connections = []
    
    for i, out1 in enumerate(output_pins):
        for j, out2 in enumerate(output_pins):
            if i != j:
                # Set one output to HIGH, other to LOW, then check if they're connected
                GPIO.output(out1, GPIO.HIGH)
                GPIO.output(out2, GPIO.LOW)
                time.sleep(0.01)
                
                # If they're connected, the HIGH should override the LOW
                # We can detect this by temporarily setting out2 as input
                GPIO.setup(out2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
                time.sleep(0.01)
                if GPIO.input(out2):  # OUT-to-OUT connection detected
                    out_to_out_connections.append((i, j))
                GPIO.setup(out2, GPIO.OUT)  # Restore as output
                GPIO.output(out2, GPIO.LOW)
    
    return out_to_out_connections

try:
    while True:
        # Test each pair individually
        pair_results = []
        for output_pin, input_pin in WIRE_PAIRS:
            is_connected = test_wire_pair(output_pin, input_pin)
            pair_results.append(is_connected)
        
        # Test for various types of cross connections
        cross_connections = test_cross_connections()
        in_to_in_connections = test_in_to_in_connections()
        out_to_out_connections = test_out_to_out_connections()
        
        # Determine status
        all_connected = all(pair_results)
        any_open = not all_connected
        has_cross_connections = (len(cross_connections) > 0 or 
                               len(in_to_in_connections) > 0 or 
                               len(out_to_out_connections) > 0)
        
        if has_cross_connections:
            print("NOT GOOD")
            GPIO.output(RED_LED, GPIO.HIGH)
            GPIO.output(GREEN_LED, GPIO.LOW)
            GPIO.output(YELLOW_LED, GPIO.LOW)
        elif all_connected:
            print("GOOD")
            GPIO.output(GREEN_LED, GPIO.HIGH)
            GPIO.output(RED_LED, GPIO.LOW)
            GPIO.output(YELLOW_LED, GPIO.LOW)
        else:
            print("OPEN")
            GPIO.output(YELLOW_LED, GPIO.HIGH)
            GPIO.output(RED_LED, GPIO.LOW)
            GPIO.output(GREEN_LED, GPIO.LOW)
        
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\nExiting and cleaning up GPIO...")
finally:
    GPIO.cleanup() 