import tkinter as tk
from tkinter import ttk
import subprocess
import sys
import os

class WireCheckerSelector:
    def __init__(self, root):
        self.root = root
        self.root.title("Wire Checker - Select Configuration")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        # Center the window
        self.root.eval('tk::PlaceWindow . center')
        
        # Create main frame
        main_frame = tk.Frame(root, bg='#f0f0f0')
        main_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        # Title
        title_label = tk.Label(main_frame, text="Wire Checker System", 
                              font=('Arial', 28, 'bold'), bg='#f0f0f0')
        title_label.pack(pady=(0, 40))
        
        # Subtitle
        subtitle_label = tk.Label(main_frame, text="Select the number of wire pairs to test:", 
                                 font=('Arial', 18), bg='#f0f0f0')
        subtitle_label.pack(pady=(0, 40))
        
        # Buttons frame
        buttons_frame = tk.Frame(main_frame, bg='#f0f0f0')
        buttons_frame.pack(pady=30)
        
        # 3 Pairs Button
        self.btn_3pairs = tk.Button(buttons_frame, text="3 Wire Pairs", 
                                    font=('Arial', 20, 'bold'),
                                    width=25, height=2,
                                    bg='#007bff', fg='white',
                                    relief='raised', borderwidth=4,
                                    command=self.run_3pairs)
        self.btn_3pairs.pack(pady=30)
        
        # 4 Pairs Button
        self.btn_4pairs = tk.Button(buttons_frame, text="4 Wire Pairs", 
                                    font=('Arial', 20, 'bold'),
                                    width=25, height=2,
                                    bg='#28a745', fg='white',
                                    relief='raised', borderwidth=4,
                                    command=self.run_4pairs)
        self.btn_4pairs.pack(pady=30)
        
        # Information frame
        info_frame = tk.Frame(main_frame, bg='#f0f0f0')
        info_frame.pack(pady=(40, 0))
        
        info_label = tk.Label(info_frame, 
                             text="3 Pairs: GPIO17↔27, GPIO22↔10, GPIO9↔11\n"
                                  "4 Pairs: GPIO17↔27, GPIO22↔10, GPIO9↔11, GPIO5↔6", 
                             font=('Arial', 14), bg='#f0f0f0', justify='left')
        info_label.pack()
        
        # Exit button
        exit_btn = tk.Button(main_frame, text="Exit", 
                            font=('Arial', 16),
                            width=15, height=2,
                            bg='#dc3545', fg='white',
                            command=self.root.destroy)
        exit_btn.pack(pady=(30, 0))
    
    def run_3pairs(self):
        """Run the 3-pair wire checker"""
        try:
            # Close the selector window
            self.root.destroy()
            
            # Run the 3-pair wire checker
            subprocess.run([sys.executable, 'wire_checker_3pairs.py'])
            
        except Exception as e:
            print(f"Error running 3-pair wire checker: {e}")
    
    def run_4pairs(self):
        """Run the 4-pair wire checker"""
        try:
            # Close the selector window
            self.root.destroy()
            
            # Run the 4-pair wire checker
            subprocess.run([sys.executable, 'wire_checker_4pairs.py'])
            
        except Exception as e:
            print(f"Error running 4-pair wire checker: {e}")

def main():
    root = tk.Tk()
    app = WireCheckerSelector(root)
    root.mainloop()

if __name__ == '__main__':
    main()
